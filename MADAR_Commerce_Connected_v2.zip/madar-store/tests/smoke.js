'use strict';
const {spawn}=require('node:child_process');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const net=require('node:net');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'madar-test-'));const db=path.join(dir,'store.sqlite');
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p))});s.on('error',reject)})}
(async()=>{const port=await freePort(),server=spawn(process.execPath,[path.join(__dirname,'..','server.js')],{env:{...process.env,PORT:String(port),HOST:'127.0.0.1',DATABASE_PATH:db,ADMIN_EMAIL:'admin@madar.test',ADMIN_PASSWORD:'SmokeTestPassword!2026',NODE_ENV:'test'},stdio:'ignore'});const base=`http://127.0.0.1:${port}`;let passed=0,uploadedPath=null;
async function call(url,method='GET',body,token){const r=await fetch(base+url,{method,headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:body?JSON.stringify(body):undefined});const d=await r.json();if(!r.ok)throw Error(`${method} ${url}: ${r.status} ${d.error}`);return d}
try{let ready=false;for(let i=0;i<50;i++){try{await call('/api/health');ready=true;break}catch{await new Promise(r=>setTimeout(r,100))}}if(!ready)throw Error('server did not start');passed++;
const products=(await call('/api/products')).products;if(products.length<8)throw Error('seed products missing');passed++;
const admin=await call('/api/login','POST',{email:'admin@madar.test',password:'SmokeTestPassword!2026'});if(admin.user.role!=='admin')throw Error('admin bootstrap failed');passed++;
const customer=await call('/api/register','POST',{name:'Smoke Customer',email:'smoke@example.test',phone:'07700000000',password:'SmokePassword!2026'});if(!customer.token)throw Error('register failed');passed++;
const upload=await call('/api/admin/upload','POST',{data:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/7x8AAAAASUVORK5CYII='},admin.token);if(!upload.url.startsWith('/uploads/'))throw Error('image upload failed');uploadedPath=path.join(__dirname,'..',upload.url);passed++;
const created=await call('/api/admin/products','POST',{name:'Smoke Product',brand:'MADAR',category:'اختبار',price:10000,oldPrice:12000,stock:4,sku:'SMOKE-001',description:'Smoke test',image:upload.url} ,admin.token);passed++;
const order=await call('/api/orders','POST',{phone:'07700000000',address:'Mosul test address',items:[{id:created.product.id,qty:2}]},customer.token);if(order.order.total!==20000)throw Error('order total incorrect');passed++;
await call('/api/reviews','POST',{productId:created.product.id,orderId:order.order.id,rating:5,comment:'verified purchase'},customer.token);passed++;
const after=(await call('/api/products')).products.find(p=>p.id===created.product.id);if(after.stock!==2||after.reviewCount!==1||after.rating!==5)throw Error('inventory/review aggregation failed');passed++;
const orders=(await call('/api/orders','GET',null,customer.token)).orders;if(orders.length!==1)throw Error('customer order history failed');passed++;
const dup=await fetch(base+'/api/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:'Smoke Customer',email:'smoke@example.test',password:'SmokePassword!2026'})});if(dup.status!==409)throw Error('duplicate email should be rejected');passed++;
console.log(`MADAR smoke tests passed: ${passed}/${passed}`);
}catch(e){console.error(e);process.exitCode=1}finally{server.kill('SIGTERM');if(uploadedPath)try{fs.rmSync(uploadedPath,{force:true})}catch{}setTimeout(()=>{try{fs.rmSync(dir,{recursive:true,force:true})}catch{}},250)}})();
